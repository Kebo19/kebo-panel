@echo off
chcp 65001 >nul
cd /d "%~dp0.."
set LOG=%~dp0canli.log
echo KEBO canliya alma basladi %date% %time% > "%LOG%"
echo.
echo  KEBO Panel CANLIYA aliniyor... Bu pencereyi kapatmayin.
echo.

echo === 1) durum === >> "%LOG%"
git remote -v >> "%LOG%" 2>&1
git branch --show-current >> "%LOG%" 2>&1
git status --short >> "%LOG%" 2>&1

rem Klasordeki tum degisiklikler (deneme ile gonderilenler + sonradan eklenenler)
rem once "deneme" dalina islenir, sonra main'e birlestirilir.
echo  [1/3] Degisiklikler hazirlaniyor...
echo === 2) deneme dali === >> "%LOG%"
git checkout -B deneme >> "%LOG%" 2>&1
if errorlevel 1 goto hata
git add -A >> "%LOG%" 2>&1
git commit -m "KEBO guncelleme %date% %time:~0,5%" >> "%LOG%" 2>&1

echo  [2/3] main dalina birlestiriliyor...
echo === 3) main + merge === >> "%LOG%"
git checkout main >> "%LOG%" 2>&1
if errorlevel 1 goto hata
git merge deneme >> "%LOG%" 2>&1
if errorlevel 1 goto hata

echo  [3/3] GitHub'a gonderiliyor (Vercel canli siteyi otomatik yayinlar)...
echo === 4) push === >> "%LOG%"
git push origin main >> "%LOG%" 2>&1
if errorlevel 1 goto hata
git push -f origin deneme >> "%LOG%" 2>&1
git log -3 --oneline >> "%LOG%" 2>&1
git status --short >> "%LOG%" 2>&1
echo TAMAM >> "%LOG%"
echo.
echo  TAMAM! Canliya gonderildi. Vercel 1-2 dk icinde yayinlar.
echo.
pause
exit /b 0

:hata
echo HATA_OLUSTU >> "%LOG%"
echo.
echo  Bir adimda hata oldu. Claude'a "bitti" yazin, canli.log kaydini inceleyip duzeltecek.
echo.
pause
exit /b 1
