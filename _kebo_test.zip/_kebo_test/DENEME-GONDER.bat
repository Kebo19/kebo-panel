@echo off
chcp 65001 >nul
cd /d "%~dp0.."
set LOG=%~dp0deneme.log
echo KEBO deneme gonderimi basladi %date% %time% > "%LOG%"
echo.
echo  KEBO Panel DENEME adresine gonderiliyor... Bu pencereyi kapatmayin (2-5 dakika).
echo  (Canli site DEGISMEZ. Canliya almak icin sonra CANLIYA-AL.bat calistirilir.)
echo.

echo  [1/4] Paketler kuruluyor...
echo === 1) npm install === >> "%LOG%"
call npm install >> "%LOG%" 2>&1

echo  [2/4] Testler calisiyor...
echo === 2) npm test === >> "%LOG%"
call npm test >> "%LOG%" 2>&1
if errorlevel 1 goto hata

echo  [3/4] Uygulama derleniyor...
echo === 3) npm run build === >> "%LOG%"
if exist .next rmdir /s /q .next
if exist .next\dev echo UYARI: .next\dev silinemedi - npm run dev acik olabilir >> "%LOG%"
set NEXT_PUBLIC_SUPABASE_URL=https://ktvarqdidplunhjcjpor.supabase.co
set NEXT_PUBLIC_SUPABASE_ANON_KEY=yerel-build-kontrolu
call npm run build >> "%LOG%" 2>&1
if errorlevel 1 goto hata

echo  [4/4] GitHub'a "deneme" dalina gonderiliyor...
echo === 4) git === >> "%LOG%"
git remote -v >> "%LOG%" 2>&1
git branch --show-current >> "%LOG%" 2>&1
rem Degisiklikler main uzerinden yeni bir "deneme" dalina alinir (eski deneme dali ezilir).
git checkout -B deneme >> "%LOG%" 2>&1
if errorlevel 1 goto hata
git add -A >> "%LOG%" 2>&1
git status --short >> "%LOG%" 2>&1
git commit -m "KEBO deneme %date% %time:~0,5%" >> "%LOG%" 2>&1
git push -f origin deneme >> "%LOG%" 2>&1
if errorlevel 1 goto hata_main
git log -3 --oneline >> "%LOG%" 2>&1
rem main dalina don; degisiklikler klasorde (kaydedilmemis olarak) kalsin ki
rem bir sonraki deneme / canliya alma bunlari da icersin.
git checkout main >> "%LOG%" 2>&1
git restore --source=deneme --worktree -- . >> "%LOG%" 2>&1
git status --short >> "%LOG%" 2>&1
echo TAMAM >> "%LOG%"
echo.
echo  TAMAM! Deneme surumu gonderildi.
echo  Vercel'de deneme adresi 1-2 dk icinde hazir olur (Vercel panelinde Deployments,
echo  "deneme" dalinin satiri). Denedikten sonra her sey yolundaysa CANLIYA-AL.bat.
echo.
pause
exit /b 0

:hata_main
git checkout main >> "%LOG%" 2>&1
git restore --source=deneme --worktree -- . >> "%LOG%" 2>&1
:hata
echo HATA_OLUSTU >> "%LOG%"
echo.
echo  Bir adimda hata oldu. Claude'a "bitti" yazin, deneme.log kaydini inceleyip duzeltecek.
echo.
pause
exit /b 1
