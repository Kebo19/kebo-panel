@echo off
chcp 65001 >nul
cd /d "%~dp0.."
set LOG=%~dp0sonuc.log
echo KEBO guncelleme basladi %date% %time% > "%LOG%"
echo.
echo  KEBO Panel guncelleniyor... Bu pencereyi kapatmayin (2-5 dakika).
echo.

echo === 1) Eski dosyalar siliniyor === >> "%LOG%"
if exist middleware.ts del /q middleware.ts
if exist lib\supabase.ts del /q lib\supabase.ts
if exist lib\resportStorage.ts del /q lib\resportStorage.ts
if exist components\Topbar.tsx del /q components\Topbar.tsx
if exist app\platform-takip rmdir /s /q app\platform-takip
if exist "app\raporlar\[id]" rmdir /s /q "app\raporlar\[id]"
if exist "app\personel\[id]\duzenle" rmdir /s /q "app\personel\[id]\duzenle"
dir /b middleware.ts proxy.ts >> "%LOG%" 2>&1

echo  [1/5] Paketler kuruluyor...
echo === 2) npm install === >> "%LOG%"
call npm install >> "%LOG%" 2>&1

echo  [3/5] Testler calisiyor...
echo === 4) npm test === >> "%LOG%"
call npm test >> "%LOG%" 2>&1
if errorlevel 1 goto hata

echo  [4/5] Uygulama derleniyor...
echo === 5) npm run build === >> "%LOG%"
if exist .next rmdir /s /q .next
if exist .next\dev echo UYARI: .next\dev silinemedi - npm run dev acik olabilir >> "%LOG%"
set NEXT_PUBLIC_SUPABASE_URL=https://ktvarqdidplunhjcjpor.supabase.co
set NEXT_PUBLIC_SUPABASE_ANON_KEY=yerel-build-kontrolu
call npm run build >> "%LOG%" 2>&1
if errorlevel 1 goto hata

echo  [5/5] GitHub'a gonderiliyor (Vercel otomatik yayinlar)...
echo === 6) git === >> "%LOG%"
git remote -v >> "%LOG%" 2>&1
git add -A >> "%LOG%" 2>&1
git status --short >> "%LOG%" 2>&1
git commit -m "KEBO guncelleme %date% %time:~0,5%" >> "%LOG%" 2>&1
git push origin HEAD >> "%LOG%" 2>&1
if errorlevel 1 goto hata
git log -3 --oneline >> "%LOG%" 2>&1
echo TAMAM >> "%LOG%"
echo.
echo  TAMAM! Guncelleme gonderildi. Claude'a "bitti" yazabilirsiniz.
echo.
pause
exit /b 0

:hata
echo HATA_OLUSTU >> "%LOG%"
echo.
echo  Bir adimda hata oldu. Claude'a "bitti" yazin, kaydi inceleyip duzeltecek.
echo.
pause
exit /b 1
