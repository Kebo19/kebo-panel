// KEBO: kağıt rapor taramasını gerçek Gemini anahtarıyla test eder.
// Çalıştırma: node _kebo_test/tara-test.mjs   (proje klasöründen)
import { readFileSync, writeFileSync } from "node:fs";

const env = readFileSync(".env.local", "utf8");
const anahtar = (env.match(/^\s*GEMINI_API_KEY\s*=\s*["']?([^"'\r\n]+)/m) || [])[1];
if (!anahtar) { console.log("SONUC: .env.local icinde GEMINI_API_KEY YOK"); process.exit(0); }
console.log("GEMINI_API_KEY bulundu (uzunluk " + anahtar.length + ")");

const route = readFileSync("app/api/rapor-tara/route.ts", "utf8");
const prompt = route.split("const SISTEM_PROMPT = `")[1].split("`;")[0];
const model = (route.match(/models\/([\w.-]+):generateContent/) || [])[1];
console.log("Model: " + model);
const resim = readFileSync("_kebo_test/ornek-form.jpg").toString("base64");

const t0 = Date.now();
const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
  method: "POST",
  headers: { "Content-Type": "application/json", "x-goog-api-key": anahtar },
  body: JSON.stringify({
    system_instruction: { parts: [{ text: prompt }] },
    contents: [{ role: "user", parts: [
      { inline_data: { mime_type: "image/jpeg", data: resim } },
      { text: "Bu KEBO kağıt kasa raporunu oku ve yalnızca JSON döndür." }] }],
    generationConfig: { responseMimeType: "application/json", maxOutputTokens: 16384, thinkingConfig: { thinkingLevel: "minimal" } },
  }),
});
const veri = await res.json().catch(() => ({}));
console.log("HTTP " + res.status + " (" + (Date.now() - t0) + " ms)");
if (!res.ok) { console.log("HATA: " + JSON.stringify(veri.error || veri)); process.exit(0); }
const aday = veri.candidates?.[0];
console.log("finishReason: " + aday?.finishReason);
const metin = aday?.content?.parts?.map(p => p.text || "").join("") || "";
writeFileSync("_kebo_test/tara-sonuc.json", metin);
console.log("SONUC_JSON_BASLANGIC");
console.log(metin);
console.log("SONUC_JSON_BITIS");
